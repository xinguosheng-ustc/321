/********************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                */
/*                                                                  */
/*  FILE NAME             :  menu.h                                 */
/*  PRINCIPAL AUTHOR      :  Xinguosheng                            */
/*  SUBSYSTEM NAME        :  menu                                   */
/*  MODULE NAME           :  menu                                   */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/29                             */
/*  DESCRIPTION           :  interface of menu                      */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by Xinguosheng,2014/09/29
 *
 */

#ifndef menu
#define menu

#include <pthread.h>

#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define CMD_NUM     10


/* data struct and its operations */
typedef struct DataNode
{
    tLinkTableNode * pNext;
    char*   cmd;
    char*   desc;
    int     (*handler)();
} tDataNode;

/* find a cmd in the linklist and return the datanode pointer */
tDataNode* FindCmd(tLinkTable * head, char * cmd);

/* show all cmd in listlist */
int ShowAllCmd(tLinkTable * head);

/* entrance to ShowAllCmd */
int Help();

/* entrance to test program */
int Test();

/* entrance to add menu list*/
int Add();

/* static struct array and its initialization */
static tDataNode data[] = 
{
    {NULL, "help", "this cmd shows menulist", Help},
    {NULL, "test", "this cmd is test", Test},
    {NULL, "add", "this cmd add cmd to menulist", Add},
    {NULL, "version", "menu program v3.0", NULL}
};





#endif 
