/**************************************************************************************************/
/* Copyright (C) 1434005644@qq.com, SSE@USTC, 2014-2015                                           */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  Xinguosheng                                                          */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/29                                                           */
/*  DESCRIPTION           :  This is a test program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Xinguosheng, 2014/09/29
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "linktable.h"
#include "menu.h"

/* menu program */

tLinkTable * head = NULL;
int Help()
{
    ShowAllCmd(head);
    return 0; 
}

main()
{   
    head = CreateLinkTable();
    AddLinkTableNode(head,(tLinkTableNode *)&data[0]);
    AddLinkTableNode(head,(tLinkTableNode *)&data[1]);
    AddLinkTableNode(head,(tLinkTableNode *)&data[2]);
    AddLinkTableNode(head,(tLinkTableNode *)&data[3]);
   /* cmd line begins */
    while(1)
    {
        char cmd[CMD_MAX_LEN];
        printf("Input a cmd number > ");
        scanf("%s", cmd);
        tDataNode *p = FindCmd(head, cmd);
        if( p == NULL)
        {
            printf("please input a right cmd!\n");
            continue;
        }
        if(p->handler == Test)
        {
            printf("only test!\n");
            break;
        } 
        if(p->handler == Add)
        {
           printf("this is add function!\n");
        }
        if(p->handler == Help) 
        { 
            p->handler();
        }
        else
        {
            printf("%s - %s\n", p->cmd, p->desc);  
        }
    }
}





